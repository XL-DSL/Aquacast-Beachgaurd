# Model Notes

## Purpose

AquaCast estimates the probability that bacteria levels may exceed recreational water-quality thresholds at a pilot recreational water site.

The project currently produces model outputs for:

- E. coli
- Enterococcus

## Backend workflow

The main backend notebook is:

```text
notebooks/AquaCast_Model_Pipeline_Version_10.ipynb
```

The notebook uses:

```text
data/Aquacast15Years_Weekly.csv
```

It trains and evaluates bacteria exceedance models, then exports a simplified prediction file for the Streamlit app.

## Streamlit V1 workflow

For V1, the app does not retrain models when a user opens it. Instead, it reads:

```text
data/app_predictions.csv
```

This keeps the web app simple, fast, and easier to debug.

## App prediction columns

`data/app_predictions.csv` includes:

- `site_name`
- `latitude`
- `longitude`
- `prediction_date`
- `data_last_updated`
- `e_coli_probability`
- `enterococcus_probability`
- `e_coli_risk`
- `enterococcus_risk`
- `overall_risk`
- `risk_color`
- `safety_message`

## Risk labels

The app displays risk levels as:

- Safe
- Caution
- Unsafe

The overall risk is based on the bacteria-specific model outputs.

## Included model files

The repository includes model metadata and feature lists in `models/`:

- `model_manifest.json`
- `e_coli_model_info.json`
- `enterococcus_model_info.json`
- `e_coli_features.txt`
- `enterococcus_features.txt`

The trained `.joblib` model files are not included in this public V1 repository because the app uses the precomputed prediction CSV. If future versions load models directly, model files should be added only if they are small, non-sensitive, and clearly documented.

## Disclaimer

This model is experimental and intended for student research and app-development purposes only. It is not an official public-health advisory system. Users should always follow official beach closure and advisory notices.
