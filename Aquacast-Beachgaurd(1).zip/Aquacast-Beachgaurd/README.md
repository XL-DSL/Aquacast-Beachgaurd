# Aquacast-Beachgaurd

AquaCast Backend is the ML pipeline for BeachGuard. It cleans bacteria and environmental data, trains E. coli and Enterococcus exceedance models, evaluates binary Safe/Unsafe metrics, and exports app-ready prediction files for water-quality risk communication.

## Public-health disclaimer

This repository is an experimental student research and app-development prototype. It is not an official public-health advisory system. Always follow official beach closure notices, city/county advisories, and public-health guidance.

## Backend purpose

This repository contains the backend files used to support a Streamlit V1 water-quality risk app:

1. A cleaned weekly dataset for the pilot site.
2. A model pipeline notebook for training and evaluation.
3. App-ready prediction outputs exported as a simple CSV.
4. Model metadata, feature lists, metrics, and documentation.
5. A Streamlit interface that reads the exported prediction CSV.

The V1 app does not retrain the model when a user opens it. It reads the precomputed output file:

```text
data/app_predictions.csv
```

## Repository structure

```text
Aquacast-Beachgaurd/
  app.py
  requirements.txt
  README.md
  LICENSE
  .gitignore

  data/
    Aquacast15Years_Weekly.csv
    app_predictions.csv
    model_binary_metrics.csv

  notebooks/
    AquaCast_Model_Pipeline_Version_10.ipynb

  docs/
    data_lineage.md
    ai_tools_disclosure.md
    model_notes.md

  assets/
    e_coli_binary_confusion_matrix.png
    enterococcus_binary_confusion_matrix.png

  models/
    model_manifest.json
    e_coli_model_info.json
    enterococcus_model_info.json
    e_coli_features.txt
    enterococcus_features.txt
```

## Key files

| File | Purpose |
|---|---|
| `app.py` | Streamlit V1 interface that displays the latest prediction output. |
| `data/app_predictions.csv` | Small app-ready prediction table used by Streamlit. |
| `data/Aquacast15Years_Weekly.csv` | Cleaned weekly backend dataset used by the model pipeline. |
| `data/model_binary_metrics.csv` | Binary model evaluation summary. |
| `notebooks/AquaCast_Model_Pipeline_Version_10.ipynb` | Main ML pipeline notebook. |
| `docs/data_lineage.md` | Public dataset sources and processing notes. |
| `docs/ai_tools_disclosure.md` | AI assistance and review disclosure. |
| `docs/model_notes.md` | Model workflow, output format, and V1 deployment notes. |

## App prediction output format

`data/app_predictions.csv` contains one app-ready row per prediction date. Required columns:

```text
site_name
latitude
longitude
prediction_date
data_last_updated
e_coli_probability
enterococcus_probability
e_coli_risk
enterococcus_risk
overall_risk
risk_color
safety_message
```

Risk labels are displayed as:

```text
Safe
Caution
Unsafe
```

## Run locally

Install dependencies:

```bash
pip install -r requirements.txt
```

Run the Streamlit app:

```bash
streamlit run app.py
```

## Deploy on Streamlit Community Cloud

1. Push this repository to GitHub as a public repository.
2. Open Streamlit Community Cloud.
3. Connect the GitHub repository.
4. Set the main file path to:

```text
app.py
```

5. Deploy and test on both a phone and a computer.

## Data sources

The data lineage is documented in `docs/data_lineage.md`. Sources include California surface-water fecal indicator bacteria records and NOAA/NCEI daily weather summaries.

## License

This project is released under the MIT License. See `LICENSE`.
