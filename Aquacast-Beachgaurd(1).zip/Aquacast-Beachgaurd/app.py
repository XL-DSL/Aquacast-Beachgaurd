from pathlib import Path

import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="AquaCast / BeachGuard",
    page_icon="🌊",
    layout="centered",
)

DATA_PATH = Path("data/app_predictions.csv")
REQUIRED_COLUMNS = [
    "site_name",
    "latitude",
    "longitude",
    "prediction_date",
    "data_last_updated",
    "e_coli_probability",
    "enterococcus_probability",
    "e_coli_risk",
    "enterococcus_risk",
    "overall_risk",
    "risk_color",
    "safety_message",
]


@st.cache_data
def load_predictions(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(missing)}")
    df["prediction_date"] = pd.to_datetime(df["prediction_date"], errors="coerce")
    df = df.dropna(subset=["prediction_date"])
    return df


st.title("AquaCast / BeachGuard")
st.caption("Experimental water-quality risk output for a pilot recreational water site")

st.info(
    "This is an experimental student research prototype. It is not an official "
    "public-health advisory system. Always follow official beach closure notices, "
    "city/county advisories, and public-health guidance."
)

try:
    predictions = load_predictions(DATA_PATH)
    if predictions.empty:
        raise ValueError("Prediction file has no valid prediction dates.")

    site_options = sorted(predictions["site_name"].dropna().unique())
    selected_site = st.sidebar.selectbox("Pilot site", site_options)

    site_predictions = predictions[predictions["site_name"] == selected_site].copy()
    site_predictions = site_predictions.sort_values("prediction_date")
    latest = site_predictions.iloc[-1]

    st.subheader(str(latest["site_name"]))
    st.write(f"Prediction date: {latest['prediction_date'].date()}")
    st.write(f"Data last updated: {latest['data_last_updated']}")

    risk = str(latest["overall_risk"])
    if risk == "Unsafe":
        st.error(f"Overall risk: {risk}")
    elif risk == "Caution":
        st.warning(f"Overall risk: {risk}")
    elif risk == "Safe":
        st.success(f"Overall risk: {risk}")
    else:
        st.warning(f"Overall risk: {risk}")

    st.write(str(latest["safety_message"]))

    st.divider()
    st.subheader("Bacteria-specific model output")

    col1, col2 = st.columns(2)
    with col1:
        st.metric(
            "E. coli probability",
            f"{float(latest['e_coli_probability']):.1%}",
            str(latest["e_coli_risk"]),
        )
    with col2:
        st.metric(
            "Enterococcus probability",
            f"{float(latest['enterococcus_probability']):.1%}",
            str(latest["enterococcus_risk"]),
        )

    st.divider()
    st.subheader("Pilot site map")
    map_df = pd.DataFrame(
        {
            "lat": [float(latest["latitude"])],
            "lon": [float(latest["longitude"])],
        }
    )
    st.map(map_df)

    with st.expander("View recent prediction rows"):
        display_cols = [
            "prediction_date",
            "e_coli_probability",
            "e_coli_risk",
            "enterococcus_probability",
            "enterococcus_risk",
            "overall_risk",
        ]
        st.dataframe(site_predictions[display_cols].tail(15), use_container_width=True)
except Exception as exc:
    st.error("Prediction currently unavailable.")
    st.caption(
        "Check whether data/app_predictions.csv exists and has the required columns. "
        f"Details: {exc}"
    )
